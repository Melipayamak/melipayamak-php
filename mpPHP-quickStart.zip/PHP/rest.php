<?php

require __DIR__ . '/vendor/autoload.php';
use Melipayamak\MelipayamakApi;
try{
    $username = 'username';
    $password = 'password';
    $api = new MelipayamakApi($username,$password);
    $sms = $api->sms();
    $to = '09123456789';
    $from = '5000...';
    $text = 'تست وب سرویس ملی پیامک';
    $response = $sms->send($to,$from,$text);
    echo $response; //RecId or Error Number 
}catch(Exception $e){
    echo $e->getMessage();
}

  ?>