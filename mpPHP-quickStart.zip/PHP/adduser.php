<?php

require __DIR__ . '/vendor/autoload.php';
use Melipayamak\MelipayamakApi;
try{
    $username = '';
    $password = '';
    $api = new MelipayamakApi($username,$password);

    $soap = $api->users();

    $params = array(
        'productId' => 1,
        'descriptions' => '',
        'mobileNumber' => '',
        'emailAddress' => '',
        'nationalCode' => '',
        'name' => '',
        'family' => '',
        'corporation' => '',
        'phone' => '',
        'fax' => '',
        'address' => '',
        'postalCode' => '',
        'certificateNumber' => ''
    );
    
    $response = $soap->add($params);
    echo $response; //RecId or Error Number 
}catch(Exception $e){
    echo $e->getMessage();
}

  ?>